function z = GetVolt()
%
%
v = 0 + 4*randn ;
z = 14.4 + v;