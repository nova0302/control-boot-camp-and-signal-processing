function z = GetVolt()
%
%
w = 0 + 4*randn ;
z = 14.4 + w;